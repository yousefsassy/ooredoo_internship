package tn.esprit.examen.nomPrenomClasseExamen.services;

import org.springframework.security.core.userdetails.User;

import java.util.List;

public interface IUserService {
    void approveUserByAdmin(Long userId);
    void deleteUserByAdmin(Long userId);
    User getUserById(Long userId);

}
