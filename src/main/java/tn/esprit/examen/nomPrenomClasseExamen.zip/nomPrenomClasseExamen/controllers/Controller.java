package tn.esprit.examen.nomPrenomClasseExamen.controllers;

import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tn.esprit.examen.nomPrenomClasseExamen.model.Zone;
import tn.esprit.examen.nomPrenomClasseExamen.services.ZoneServiceImpl;

import java.util.List;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequiredArgsConstructor
public class Controller {
    @Autowired
    private ZoneServiceImpl zoneService;

    // Create a new zone
    @PostMapping("/createZone")
    public ResponseEntity<Zone> createZone(@RequestBody Zone zone) {
        Zone createdZone = zoneService.createZone(zone);
        return ResponseEntity.ok(createdZone);
    }

    // Update existing zone
    @PutMapping("/updateZone/{id}")
    public ResponseEntity<Zone> updateZone(@PathVariable Long id, @RequestBody Zone zone) {
        Zone updatedZone = zoneService.updateZone(id, zone);
        return ResponseEntity.ok(updatedZone);
    }

    // Delete a zone
    @DeleteMapping("/deleteZone/{id}")
    public ResponseEntity<Void> deleteZone(@PathVariable Long id) {
        zoneService.deleteZone(id);
        return ResponseEntity.noContent().build();
    }

    // Get all zones
    @GetMapping("/getAllZones")
    public ResponseEntity<List<Zone>> getAllZones() {
        List<Zone> zones = zoneService.getAllZones();
        return ResponseEntity.ok(zones);
    }

    // Get zone by id
    @GetMapping("/getZoneById/{id}")
    public ResponseEntity<Zone> getZoneById(@PathVariable Long id) {
        Zone zone = zoneService.getZoneById(id)
                .orElseThrow(() -> new RuntimeException("Zone not found with id " + id));
        return ResponseEntity.ok(zone);
    }
}
