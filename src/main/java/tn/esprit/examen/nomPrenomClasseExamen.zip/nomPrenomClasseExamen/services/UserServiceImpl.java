package tn.esprit.examen.nomPrenomClasseExamen.services;

import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Service;
import tn.esprit.examen.nomPrenomClasseExamen.repositories.UserRepository;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements IUserService {
    private final UserRepository userRepository;

    @Override
    public void approveUserByAdmin(Long userId) {

    }

    @Override
    public void deleteUserByAdmin(Long userId) {

    }

    @Override
    public User getUserById(Long userId) {
        return null;
    }




}
