package tn.esprit.examen.nomPrenomClasseExamen.model;

import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Shop {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idShop;
    private String nomShop;
    private String telephone;
    @OneToOne
    @JoinColumn(name = "admin_shop_id")
    private User adminShop;
    @ManyToOne
    @JoinColumn(name = "zone_id")
    private Zone zone;
}
