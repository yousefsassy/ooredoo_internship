package tn.esprit.examen.nomPrenomClasseExamen.services;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tn.esprit.examen.nomPrenomClasseExamen.model.Zone;
import tn.esprit.examen.nomPrenomClasseExamen.repositories.ZoneRepository;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ZoneServiceImpl implements IZoneService {
    @Autowired
    private ZoneRepository zoneRepository;

    @Override
    public Zone createZone(Zone zone) {
        return zoneRepository.save(zone);
    }

    @Override
    public Zone updateZone(Long id, Zone zoneDetails) {
        Zone zone = zoneRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Zone not found with id " + id));

        zone.setLibelle(zoneDetails.getLibelle());
        zone.setGouvernorat(zoneDetails.getGouvernorat());
        zone.setDelegation(zoneDetails.getDelegation());
        zone.setAdresse(zoneDetails.getAdresse());
        // Ne pas oublier de gérer les relations si besoin (ex: chefZone, shops...)

        return zoneRepository.save(zone);
    }

    @Override
    public void deleteZone(Long id) {
        Zone zone = zoneRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Zone not found with id " + id));
        zoneRepository.delete(zone);
    }

    @Override
    public Optional<Zone> getZoneById(Long id) {
        return zoneRepository.findById(id);
    }

    @Override
    public List<Zone> getAllZones() {
        return zoneRepository.findAll();
    }
}
