package tn.esprit.examen.nomPrenomClasseExamen.services;

import tn.esprit.examen.nomPrenomClasseExamen.model.Zone;

import java.util.List;
import java.util.Optional;

public interface IZoneService {
    Zone createZone(Zone zone);
    Zone updateZone(Long id, Zone zone);
    void deleteZone(Long id);
    Optional<Zone> getZoneById(Long id);
    List<Zone> getAllZones();
}
