import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService, Zone } from '../user.service';

@Component({
  selector: 'app-zone',
  templateUrl: './zone.component.html',
  styleUrls: ['./zone.component.css']
})
export class ZoneComponent implements OnInit {
  zoneForm!: FormGroup;

  gouvernorats: string[] = [
  'Tunis', 'Ariana', 'Ben Arous', 'Manouba', 'Nabeul', 'Bizerte',
  'Beja', 'Jendouba', 'Kef', 'Siliana', 'Sousse', 'Monastir',
  'Mahdia', 'Sfax', 'Kairouan', 'Kasserine', 'Sidi Bouzid',
  'Gabes', 'Mednine', 'Tataouine', 'Gafsa', 'Tozeur', 'Kebili', 'Zaghouan'
];

delegationsMap: { [key: string]: string[] } = {
  'Tunis': ['Bab El Bhar', 'El Menzah', 'La Marsa', 'Carthage', 'Sidi Bou Said', 'Sidi El Béchir', 'Le Kram', 'Bab Souika'],
  'Ariana': ['Raoued', 'La Soukra', 'Mnihla', 'Ettadhamen', 'Kalâat el-Andalous', 'Ghazela'],
  'Ben Arous': ['Ben Arous', 'Fouchana', 'Ezzahra', 'Mohamedia', 'Mornag', 'Mégrine'],
  'Manouba': ['Manouba', 'Douar Hicher', 'Oued Ellil', 'Borj El Amri', 'Den Den'],
  'Nabeul': ['Nabeul', 'El Mida', 'Hammamet', 'Dar Chaabane', 'Kelibia', 'Korba', 'Takelsa', 'Béni Khalled', 'Grombalia', 'Menzel Temime'],
  'Bizerte': ['Bizerte', 'Menzel Bourguiba', 'Mateur', 'Ras Jebel', 'Tinja', 'Sejenane', 'Rafraf', 'Ghar El Melh'],
  'Beja': ['Beja Nord', 'Beja Sud', 'Testour', 'Goubellat', 'Medjez El Bab', 'Nefza', 'Téboursouk'],
  'Jendouba': ['Jendouba', 'Ain Draham', 'Fernana', 'Bousalem', 'Ghardimaou', 'Oued Meliz', 'Balta Bou Aouane'],
  'Kef': ['El Kef', 'Nebeur', 'Tajerouine', 'Kalâat Khasba', 'Sakiet Sidi Youssef', 'Kalaat Senan', 'Dahmani'],
  'Siliana': ['Siliana Nord', 'Siliana Sud', 'Bargou', 'El Krib', 'Rouhia', 'Sidi Bou Rouis', 'Gaafour', 'Bouarada'],
  'Sousse': ['Sousse Jawhara', 'Msaken', 'Akouda', 'Kalaa Kebira', 'Kalaa Sghira', 'Hammam Sousse', 'Sidi Bou Ali'],
  'Monastir': ['Monastir', 'Teboulba', 'Ksibet El Mediouni', 'Jemmal', 'Beni Hassen', 'Bekalta'],
  'Mahdia': ['Mahdia', 'Chebba', 'El Jem', 'Ksour Essaf', 'Ouled Chamekh', 'Sidi Alouane', 'Hebira'],
  'Sfax': ['Sfax Ville', 'Sakiet Ezzit', 'Agareb', 'Mahares', 'Skhira', 'Thyna', 'El Amra', 'Bir Ali Ben Khalifa'],
  'Kairouan': ['Kairouan Nord', 'Kairouan Sud', 'Bou Hajla', 'Haffouz', 'Oueslatia', 'Sbikha', 'Chebika'],
  'Kasserine': ['Kasserine Nord', 'Kasserine Sud', 'Fériana', 'Thala', 'Sbeitla', 'Sbiba', 'Ezzouhour'],
  'Sidi Bouzid': ['Sidi Bouzid Est', 'Sidi Bouzid Ouest', 'Meknassy', 'Regueb', 'Jilma', 'Souk Jedid'],
  'Gabes': ['Gabes Medina', 'Gabes Ouest', 'Mareth', 'Nouvelle Matmata', 'Menzel El Habib'],
  'Mednine': ['Mednine Nord', 'Mednine Sud', 'Beni Khedache', 'Djerba Houmt Souk', 'Djerba Midoun'],
  'Tataouine': ['Tataouine Nord', 'Tataouine Sud', 'Dhiba', 'Ghomrassen'],
  'Gafsa': ['Gafsa Ville', 'El Ksar', 'Mdhila', 'Metlaoui', 'Redeyef'],
  'Tozeur': ['Tozeur', 'Nefta', 'Degueche', 'Hazoua'],
  'Kebili': ['Kebili Nord', 'Kebili Sud', 'Douz Nord', 'Douz Sud'],
  'Zaghouan': ['Zaghouan', 'Bir Mchergua', 'Nadhour', 'El Fahs']
};

  delegationsFiltered: string[] = [];

  constructor(private fb: FormBuilder, private userService: UserService) {}

  ngOnInit(): void {
    this.zoneForm = this.fb.group({
      libelle: ['', Validators.required],
      gouvernorat: ['', Validators.required],
      delegation: ['', Validators.required],
      adresse: ['', Validators.required]
    });
  }

  onGouvernoratChange(): void {
    const selectedGov = this.zoneForm.get('gouvernorat')?.value;
    this.delegationsFiltered = this.delegationsMap[selectedGov] || [];
    this.zoneForm.patchValue({ delegation: '' }); // reset delegation
  }

  onSubmit(): void {
    if (this.zoneForm.invalid) return;

    const zone: Zone = this.zoneForm.value;

    this.userService.createZone(zone).subscribe({
      next: (res) => {
        console.log('Zone created successfully:', res);
        alert('Zone added successfully!');
        this.zoneForm.reset();
        this.delegationsFiltered = [];
      },
      error: (err) => {
        console.error('Error creating zone:', err);
        alert('Failed to add zone. Please try again.');
      }
    });
  }

}
