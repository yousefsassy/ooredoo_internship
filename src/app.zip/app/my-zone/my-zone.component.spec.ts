import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyZoneComponent } from './my-zone.component';

describe('MyZoneComponent', () => {
  let component: MyZoneComponent;
  let fixture: ComponentFixture<MyZoneComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [MyZoneComponent]
    });
    fixture = TestBed.createComponent(MyZoneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
