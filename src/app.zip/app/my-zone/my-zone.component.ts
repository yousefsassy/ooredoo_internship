import { Component, OnInit } from '@angular/core';
import { UserService, Zone } from '../user.service';

@Component({
  selector: 'app-my-zone',
  templateUrl: './my-zone.component.html',
  styleUrls: ['./my-zone.component.css']
})
export class MyZoneComponent implements OnInit{
  zone!: Zone;
  errorMessage: string = '';

  constructor(private userService: UserService) {}

  ngOnInit(): void {
    const token = localStorage.getItem('token');
    if (!token) {
      this.errorMessage = 'Token non trouvé';
      return;
    }

    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      const username = payload.sub || payload.Username;
      const role = payload.role;

      if (role === 'CHEFZONE') {
        this.userService.getZoneByChefUsername(username).subscribe({
          next: (zoneData) => this.zone = zoneData,
          error: (err) => {
            console.error('Erreur lors de la récupération de la zone :', err);
            this.errorMessage = 'Erreur lors de la récupération de votre zone.';
          }
        });
      } else {
        this.errorMessage = 'Accès non autorisé. Seul un chef de zone peut voir cette information.';
      }
    } catch (e) {
      console.error('Erreur de décodage du token :', e);
      this.errorMessage = 'Token invalide';
    }
  }

}
