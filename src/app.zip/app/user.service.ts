import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, throwError } from 'rxjs';

export interface User {
  id: number;
  username: string;
  email: string;
  roleName: string; // ✅ changed from role
  status: string;
  createdDate: string;
}

export interface Zone {
  idZone?: number;   // optionnel à la création
  libelle: string;
  gouvernorat: string;
  delegation: string;
  adresse: string;
  
}
export interface Shop {
  idShop?: number;
  nomShop: string;
  telephone: string;
  adminShop?: {
    id: number;
    username?: string;
    email?: string;
  };
  zone?: {
    idZone: number;
    libelle?: string;
  };
}



@Injectable({
  providedIn: 'root'
})
export class UserService {

     private apiUrl = 'http://localhost:8089/Ooredoo';

  constructor(private http: HttpClient) {}

  // Récupérer le token et créer les headers d'authentification
  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('token'); // ou 'authToken' selon ce que tu stockes
    return new HttpHeaders().set('Authorization', `Bearer ${token}`);
  }

  // Gestion des erreurs centralisée
  private handleError(error: HttpErrorResponse) {
    let errorMessage = 'An unknown error occurred!';
    if (error.error instanceof ErrorEvent) {
      errorMessage = `Client error: ${error.error.message}`;
    } else {
      errorMessage = `Server returned code ${error.status}, message: ${error.message}`;
    }
    console.error(errorMessage);
    return throwError(() => new Error(errorMessage));
  }

  // Users
  getAllUsers(): Observable<User[]> {
    const headers = this.getAuthHeaders();
    return this.http.get<User[]>(`${this.apiUrl}/auth/admin/users`, { headers }).pipe(catchError(this.handleError));
  }

  approveUser(userId: number): Observable<void> {
    const headers = this.getAuthHeaders();
    return this.http.post<void>(`${this.apiUrl}/auth/admin/approve/${userId}`, {}, { headers }).pipe(catchError(this.handleError));
  }

  // Zones
  getAllZones(): Observable<Zone[]> {
    const headers = this.getAuthHeaders();
    return this.http.get<Zone[]>(`${this.apiUrl}/getAllZones`, { headers }).pipe(catchError(this.handleError));
  }

  getZoneById(id: number): Observable<Zone> {
    const headers = this.getAuthHeaders();
    return this.http.get<Zone>(`${this.apiUrl}/getZoneById/${id}`, { headers }).pipe(catchError(this.handleError));
  }

  createZone(zone: Zone): Observable<Zone> {
    const headers = this.getAuthHeaders();
    return this.http.post<Zone>(`${this.apiUrl}/createZone`, zone, { headers }).pipe(catchError(this.handleError));
  }

  updateZone(id: number, zone: Zone): Observable<Zone> {
    const headers = this.getAuthHeaders();
    return this.http.put<Zone>(`${this.apiUrl}/updateZone/${id}`, zone, { headers }).pipe(catchError(this.handleError));
  }

  deleteZone(id: number): Observable<void> {
    const headers = this.getAuthHeaders();
    return this.http.delete<void>(`${this.apiUrl}/deleteZone/${id}`, { headers }).pipe(catchError(this.handleError));
  }

  // Shops
 getAllShops(): Observable<Shop[]> {
    const headers = this.getAuthHeaders();
    return this.http.get<Shop[]>(`${this.apiUrl}/getAllShops`, { headers }).pipe(catchError(this.handleError));
  }

  getShopById(id: number): Observable<Shop> {
    const headers = this.getAuthHeaders();
    return this.http.get<Shop>(`${this.apiUrl}/getShopById/${id}`, { headers }).pipe(catchError(this.handleError));
  }

  createShop(shop: Shop): Observable<Shop> {
    const headers = this.getAuthHeaders();
    return this.http.post<Shop>(`${this.apiUrl}/createShop`, shop, { headers }).pipe(catchError(this.handleError));
  }

  updateShop(id: number, shop: Shop): Observable<Shop> {
    const headers = this.getAuthHeaders();
    return this.http.put<Shop>(`${this.apiUrl}/updateShop/${id}`, shop, { headers }).pipe(catchError(this.handleError));
  }

  deleteShop(id: number): Observable<void> {
    const headers = this.getAuthHeaders();
    return this.http.delete<void>(`${this.apiUrl}/deleteShop/${id}`, { headers }).pipe(catchError(this.handleError));
  }

  archiveShop(id: number): Observable<void> {
    const headers = this.getAuthHeaders();
    return this.http.put<void>(`${this.apiUrl}/archiveShop/${id}`, {}, { headers }).pipe(catchError(this.handleError));
  }
  getShopsByChefZone(userId: number): Observable<Shop[]> {
  return this.http.get<Shop[]>(`${this.apiUrl}/by-chefzone/${userId}`);
}
getShopsByChefZoneUsername(username: string): Observable<Shop[]> {
  const headers = this.getAuthHeaders();
  return this.http.get<Shop[]>(`${this.apiUrl}/by-chefzone-username/${username}`, { headers })
    .pipe(catchError(this.handleError));
}
getZoneByChefUsername(username: string): Observable<Zone> {
  const headers = this.getAuthHeaders();
  return this.http.get<Zone>(`${this.apiUrl}/zone/by-chef/${username}`, { headers });
}
getShopByAdminUsername(username: string): Observable<Shop> {
  const headers = this.getAuthHeaders();
  return this.http.get<Shop>(`${this.apiUrl}/shop/by-admin/${username}`, { headers });
}
getUserStatistics(): Observable<any> {
  return this.http.get<any>('http://localhost:8089/Ooredoo/auth/admin/user-statistics');
}


getZonePercentageByGouvernorat() {
  return this.http.get<{ [key: string]: number }>(`http://localhost:8089/Ooredoo/zones-by-gouvernorat`);
}

getShopPercentageByGouvernorat() {
  return this.http.get<{ [key: string]: number }>(`http://localhost:8089/Ooredoo/shops-by-gouvernorat`);
}

getShopPercentageByZonePerGouvernorat() {
  return this.http.get<{ [gov: string]: { [zoneId: number]: number } }>(`http://localhost:8089/Ooredoo/shops-by-zone-per-gouvernorat`);
}
getZonesWithoutChefCount(): Observable<number> {
  return this.http.get<number>(`http://localhost:8089/Ooredoo/zones-without-chef`);
}
getShopsByZone(zoneId: number): Observable<any[]> {
    return this.http.get<any[]>(`http://localhost:8089/Ooredoo/shops/${zoneId}`);

}
}
