import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { jwtDecode } from 'jwt-decode';
import { filter } from 'rxjs/operators';

interface NavLink {
  label: string;
  iconClass: string;
  route: string;
}

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  currentUsername: string = 'User';
  userRole: string = '';
  navLinks: NavLink[] = [];

  constructor(private router: Router) {}

  ngOnInit(): void {
    this.loadUserInfo();

    this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe(() => {
        this.loadUserInfo();
      });
  }

  loadUserInfo(): void {
    const token = localStorage.getItem('token');
    if (token) {
      try {
        const decoded: any = jwtDecode(token);
        this.currentUsername = decoded.sub || decoded.Username || 'User';
        this.userRole = (decoded.role || '').toLowerCase();  // Convertit "CHEFZONE" → "chefzone"
        console.log('Décodage du token :', decoded);
        console.log('Rôle détecté :', this.userRole);
      } catch (err) {
        console.error('Erreur lors du décodage du token:', err);
        this.currentUsername = 'User';
        this.userRole = '';
      }
    } else {
      this.currentUsername = 'User';
      this.userRole = '';
    }

    this.setNavLinks();
  }

  setNavLinks() {
    if (this.userRole === 'admin') {
      this.navLinks = [
        { label: 'Dashboard', iconClass: 'fas fa-tachometer-alt', route: '/DashboardAdmin' },
        { label: 'Zones', iconClass: 'fas fa-map-marked-alt', route: 'zone-list' },
        { label: 'Shops', iconClass: 'fas fa-store', route: 'shop-list' },
        { label: 'Users', iconClass: 'fas fa-users', route: 'user-list' }
      ];
    } else if (this.userRole === 'adminshop') {
      this.navLinks = [
        { label: 'Dashboard', iconClass: 'fas fa-tachometer-alt', route: '/dashboard' },
        { label: 'My Shop', iconClass: 'fas fa-store', route: '/myShop' }
      ];
    } else if (this.userRole === 'chefzone') {
      this.navLinks = [
        { label: 'Dashboard', iconClass: 'fas fa-tachometer-alt', route: '/dashboard' },
        { label: 'My Zone', iconClass: 'fas fa-map-marked-alt', route: '/myZone' },
        { label: 'Shops in Zone', iconClass: 'fas fa-store', route: '/shop-list' }
      ];
    } else {
      this.navLinks = [
        { label: 'Dashboard', iconClass: 'fas fa-tachometer-alt', route: '/dashboard' }
      ];
    }
  }

  logout(): void {
    localStorage.removeItem('token');
    localStorage.removeItem('userClaims');
    this.router.navigate(['/login']);
  }
}
