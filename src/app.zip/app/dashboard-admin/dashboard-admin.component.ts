import { Component, OnInit } from '@angular/core';
import { Shop, User, UserService, Zone } from '../user.service';

@Component({
  selector: 'app-dashboard-admin',
  templateUrl: './dashboard-admin.component.html',
  styleUrls: ['./dashboard-admin.component.css']
})
export class DashboardAdminComponent implements OnInit {
  stats: any;
  zonePercentages: { [key: string]: number } = {};
  shopPercentages: { [key: string]: number } = {};
  shopPercentagesByZone: { [gov: string]: { [zoneId: number]: number } } = {};
  errorMessage: string = '';
zonesWithoutChefCount: number = 0;
  constructor(private userService: UserService) {}

  ngOnInit(): void {
    this.loadUserStatistics();
    this.loadZonePercentages();
    this.loadShopPercentages();
    this.loadShopPercentagesByZone();
    this.loadZonesWithoutChefCount();
  }

  loadUserStatistics() {
    this.userService.getUserStatistics().subscribe({
      next: data => this.stats = data,
      error: err => this.errorMessage = 'Error loading user statistics.'
    });
  }

  loadZonePercentages() {
    this.userService.getZonePercentageByGouvernorat().subscribe({
      next: data => this.zonePercentages = data,
      error: err => this.errorMessage = 'Error loading zone percentages.'
    });
  }

  loadShopPercentages() {
    this.userService.getShopPercentageByGouvernorat().subscribe({
      next: data => this.shopPercentages = data,
      error: err => this.errorMessage = 'Error loading shop percentages.'
    });
  }

  loadShopPercentagesByZone() {
    this.userService.getShopPercentageByZonePerGouvernorat().subscribe({
      next: data => this.shopPercentagesByZone = data,
      error: err => this.errorMessage = 'Error loading shop percentages by zone.'
    });
  }
  
  loadZonesWithoutChefCount() {
  this.userService.getZonesWithoutChefCount().subscribe({
    next: count => this.zonesWithoutChefCount = count,
    error: err => this.errorMessage = 'Error loading zones without chef count.'
  });
}


}
