import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { Shop, UserService, Zone } from '../user.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-shop-zone',
  templateUrl: './shop-zone.component.html',
  styleUrls: ['./shop-zone.component.css']
})


export class ShopZoneComponent implements OnInit {
  zoneId!: number;
  zoneName: string = '';
  shops: Shop[] = [];

  constructor(
    private route: ActivatedRoute,
    private router: Router,       // Injection du Router manquant
    private userService: UserService
  ) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const id = params.get('id');
      if (id) {
        this.zoneId = +id;
        this.loadZone();
        this.loadShops();
      } else {
        console.error('Zone ID manquant dans la route');
      }
    });
  }

  loadZone() {
    this.userService.getZoneById(this.zoneId).subscribe({
      next: (zone: Zone) => {
        this.zoneName = zone.libelle;
      },
      error: err => {
        console.error('Erreur récupération zone:', err);
        this.zoneName = 'Zone inconnue';
      }
    });
  }

  loadShops() {
    this.userService.getShopsByZone(this.zoneId).subscribe({
      next: data => {
        this.shops = data;
      },
      error: err => {
        console.error('Erreur récupération shops:', err);
        this.shops = [];
      }
    });
  }

  onViewShop(id: number) {
    this.router.navigate(['/shop/details', id]);
  }

  onEditShop(id: number) {
    this.router.navigate(['/shop/edit', id]);
  }

  onArchiveShop(id: number) {
    if (confirm('Are you sure you want to archive this shop?')) {
      this.userService.archiveShop(id).subscribe({
        next: () => {
          alert('Shop archived successfully!');
          this.loadShops(); // recharge la liste
        },
        error: err => console.error('Error archiving shop:', err)
      });
    }
  }

}