import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShopZoneComponent } from './shop-zone.component';

describe('ShopZoneComponent', () => {
  let component: ShopZoneComponent;
  let fixture: ComponentFixture<ShopZoneComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ShopZoneComponent]
    });
    fixture = TestBed.createComponent(ShopZoneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
