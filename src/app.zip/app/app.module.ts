import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TestComponent } from './test/test.component';
import { RegisterComponent } from './register/register.component';
import { ActivateaccountComponent } from './activateaccount/activateaccount.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { UserListComponent } from './user-list/user-list.component';

import { CommonModule } from '@angular/common';
import { RegisterChefzoneComponent } from './register-chefzone/register-chefzone.component';
import { RegisterAdminshopComponent } from './register-adminshop/register-adminshop.component';
import { ShopComponent } from './shop/shop.component';
import { ZoneComponent } from './zone/zone.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { ZoneListComponent } from './zone-list/zone-list.component';
import { ShopListComponent } from './shop-list/shop-list.component';
import { MyZoneComponent } from './my-zone/my-zone.component';
import { MyShopComponent } from './my-shop/my-shop.component';
import { DashboardAdminComponent } from './dashboard-admin/dashboard-admin.component';
import { ShopZoneComponent } from './shop-zone/shop-zone.component';




@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    TestComponent,
    RegisterComponent,
    ActivateaccountComponent,
    ForgotPasswordComponent,
    ResetPasswordComponent,
    HeaderComponent,
    FooterComponent,
    UserListComponent,
    RegisterChefzoneComponent,
    RegisterAdminshopComponent,
    ShopComponent,
    ZoneComponent,
    WelcomeComponent,
    ZoneListComponent,
    ShopListComponent,
    MyZoneComponent,
    MyShopComponent,
    DashboardAdminComponent,
    ShopZoneComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    CommonModule
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
