import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthenticationService } from '../auth/auth.service';

@Component({
  selector: 'app-register-adminshop',
  templateUrl: './register-adminshop.component.html',
  styleUrls: ['./register-adminshop.component.css']
})
export class RegisterAdminshopComponent implements OnInit {
  form!: FormGroup;
  baseData: any;
  msgerror = '';
  isloading = false;

  constructor(private fb: FormBuilder, private authService: AuthenticationService, private router: Router) {}

  ngOnInit(): void {
    const data = localStorage.getItem('partialRegister');
    if (!data) {
      this.router.navigate(['/register']);
      return;
    }

    this.baseData = JSON.parse(data);

    this.form = this.fb.group({
      shopName: ['', Validators.required],
      address: ['', Validators.required]
    });
  }

  onSubmit(): void {
    if (this.form.invalid) return;

    this.isloading = true;

    const fullData = {
      ...this.baseData,
      ...this.form.value
    };

    this.authService.register(fullData).subscribe({
      next: () => {
        this.isloading = false;
        localStorage.removeItem('partialRegister');
        this.router.navigate(['/activateaccount'], {
          queryParams: { username: fullData.username }
        });
      },
      error: (err: { message: string; }) => {
        this.isloading = false;
        this.msgerror = err?.message || 'Erreur complémentaire adminshop';
      }
    });
  }
}
