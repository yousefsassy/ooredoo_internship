import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { TestComponent } from './test/test.component';
import { RegisterComponent } from './register/register.component';
import { ActivateaccountComponent } from './activateaccount/activateaccount.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { UserListComponent } from './user-list/user-list.component';
import { RegisterAdminshopComponent } from './register-adminshop/register-adminshop.component';
import { RegisterChefzoneComponent } from './register-chefzone/register-chefzone.component';
import { ZoneComponent } from './zone/zone.component';
import { ShopComponent } from './shop/shop.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { ZoneListComponent } from './zone-list/zone-list.component';
import { ShopListComponent } from './shop-list/shop-list.component';
import { MyZoneComponent } from './my-zone/my-zone.component';
import { MyShopComponent } from './my-shop/my-shop.component';
import { DashboardAdminComponent } from './dashboard-admin/dashboard-admin.component';
import { ShopZoneComponent } from './shop-zone/shop-zone.component';

const routes: Routes = [

  {
            
            path:'login',
            component:LoginComponent},
            { path: '', component: WelcomeComponent },
            {
            path:'test',
            component:TestComponent},
            
             {path:'register',
              component:RegisterComponent},
              {path:'activateaccount',
              component:ActivateaccountComponent},
              {path:'ForgotPassword',
              component:ForgotPasswordComponent},
              {
  path: 'ResetPassword',
  component: ResetPasswordComponent
},

{
  path: 'reset-password/:token',
  component: ResetPasswordComponent
},
{
  path: 'user-list',
  component: UserListComponent
},

{
  path: 'register-adminshop',
  component: RegisterAdminshopComponent
},
{
  path: 'register-chefzone',
  component: RegisterChefzoneComponent
},
{
  path: 'zone',
  component: ZoneComponent
},
{
  path: 'shop',
  component: ShopComponent
},
{
  path: 'zone-list',
  component: ZoneListComponent
},
{
  path: 'shop-list',
  component: ShopListComponent
},
{
  path: 'myZone',
  component: MyZoneComponent
},
{
  path: 'myShop',
  component: MyShopComponent
},
{
  path: 'DashboardAdmin',
  component: DashboardAdminComponent
},
{ path: 'ShopZone/:id', component: ShopZoneComponent }







              

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
