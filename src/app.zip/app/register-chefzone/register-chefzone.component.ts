import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthenticationService } from '../auth/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register-chefzone',
  templateUrl: './register-chefzone.component.html',
  styleUrls: ['./register-chefzone.component.css']
})
export class RegisterChefzoneComponent implements OnInit {
  form!: FormGroup;
  baseData: any;
  msgerror = '';
  isloading = false;

  // ✅ Tunisian zones for the dropdown
  tunisianZones: string[] = [
    'Ariana', 'Béja', 'Ben Arous', 'Bizerte', 'Gabès', 'Gafsa',
    'Jendouba', 'Kairouan', 'Kasserine', 'Kébili', 'Kef', 'Mahdia',
    'La Manouba', 'Médenine', 'Monastir', 'Nabeul', 'Sfax', 'Sidi Bouzid',
    'Siliana', 'Sousse', 'Tataouine', 'Tozeur', 'Tunis', 'Zaghouan'
  ];

  constructor(
    private fb: FormBuilder,
    private authService: AuthenticationService,
    private router: Router
  ) {}

  ngOnInit(): void {
    const data = localStorage.getItem('partialRegister');
    if (!data) {
      this.router.navigate(['/register']);
      return;
    }

    this.baseData = JSON.parse(data);

    this.form = this.fb.group({
      zone: ['', Validators.required],
      phoneNumber: ['', Validators.required]
    });
  }

  onSubmit(): void {
    if (this.form.invalid) return;

    this.isloading = true;

    const fullData = {
      ...this.baseData,
      ...this.form.value
    };

    this.authService.register(fullData).subscribe({
      next: () => {
        this.isloading = false;
        localStorage.removeItem('partialRegister');
        this.router.navigate(['/activateaccount'], {
          queryParams: { username: fullData.username }
        });
      },
      error: (err: { message: string }) => {
        this.isloading = false;
        this.msgerror = err?.message || 'Erreur complémentaire chef zone';
      }
    });
  }
}
