import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Shop, User, UserService, Zone } from '../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-shop',
  templateUrl: './shop.component.html',
  styleUrls: ['./shop.component.css']
})
export class ShopComponent implements OnInit{
   shopForm!: FormGroup;
  users: User[] = [];
  zones: Zone[] = [];

  constructor(
    private userService: UserService,
    private router: Router,
    private fb: FormBuilder
  ) {}

  ngOnInit(): void {
    this.shopForm = this.fb.group({
      nomShop: ['', Validators.required],
      telephone: ['', [Validators.required, Validators.pattern(/^\+?\d{6,15}$/)]],
      adminShop: [''], // stockera l'ID (number) du user admin
      zone: ['', Validators.required]       // stockera l'ID de la zone
    });

    this.loadUsers();
    this.loadZones();
  }

  loadUsers(): void {
    this.userService.getAllUsers().subscribe({
      next: users => {
        this.users = users.filter(user => user.roleName?.toLowerCase() === 'admin shop');
      },
      error: err => console.error('Erreur chargement users:', err)
    });
  }

  loadZones(): void {
    this.userService.getAllZones().subscribe({
      next: zones => this.zones = zones,
      error: err => console.error('Erreur chargement zones:', err)
    });
  }

  onSubmit(): void {
    if (this.shopForm.invalid) {
      this.shopForm.markAllAsTouched();
      return;
    }

    const formValue = this.shopForm.value;

    const newShop: Shop = {
      nomShop: formValue.nomShop,
      telephone: formValue.telephone,
      adminShop: formValue.adminShop ? { id: formValue.adminShop } : undefined, // ✅ fix ici
      zone: { idZone: formValue.zone }
    };

    this.userService.createShop(newShop).subscribe({
      next: () => {
        alert('Shop créé avec succès !');
        this.router.navigate(['/shops']);
      },
      error: err => {
        console.error('Erreur création shop:', err);
        alert('Erreur lors de la création du shop.');
      }
    });
  }

}
